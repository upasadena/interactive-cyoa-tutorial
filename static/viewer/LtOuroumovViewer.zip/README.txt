Please note that this viewer has custom CSS (styling) in it.

If you do not wish to have this for your CYOA, feel free to either delete
the custom.css file in the "css/" folder, or remove the
"<link href=css/custom.css rel=stylesheet>" line in "index.html".
